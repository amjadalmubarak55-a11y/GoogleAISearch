package com.gsearch;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class GoogleAISearchMod implements ModInitializer {

    public static final String MOD_ID = "googleaisearch";
    private static final Set<String> VALID_3D = Set.of(
            "void_greatsword", "nuke_launcher", "thor_hammer", "steal_rod",
            "blackhole_staff", "dragon_bow", "royal_crown", "lucky_cube"
    );

    private ModConfig config;
    private GeminiClient gemini;

    @Override
    public void onInitialize() {
        this.config = ModConfig.load();
        this.gemini = new GeminiClient(config);
        AbilityHandler.register();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) -> {
            var cmd = CommandManager.literal("search")
                    .then(CommandManager.argument("query", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                String query = StringArgumentType.getString(ctx, "query");
                                handleSearch(player, query);
                                return 1;
                            }));
            dispatcher.register(cmd);
        });
    }

    private void handleSearch(ServerPlayerEntity player, String query) {
        if (config.gemini_api_key == null || config.gemini_api_key.isEmpty() || config.gemini_api_key.equals("PASTE_YOUR_GEMINI_API_KEY_HERE")) {
            player.sendMessage(Text.literal("[Google AI] Put your Gemini API key in config/google_ai_search.json and restart!").formatted(Formatting.RED), false);
            return;
        }
        player.sendMessage(Text.literal("[Google AI] Crafting 3 custom 3D items for '" + query + "'...").formatted(Formatting.AQUA), false);

        gemini.searchTop3(query).whenComplete((items, err) -> player.getServer().execute(() -> {
            if (err != null) {
                player.sendMessage(Text.literal("[Google AI] Gemini Error: " + err.getMessage()).formatted(Formatting.RED), false);
                return;
            }
            openGoogleGui(player, query, items);
        }));
    }

    private void openGoogleGui(ServerPlayerEntity player, String query, List<GeneratedItem> results) {
        SimpleInventory inv = new SimpleInventory(27);
        ItemStack white = new ItemStack(Items.WHITE_STAINED_GLASS_PANE);
        white.set(DataComponentTypes.CUSTOM_NAME, Text.literal(" "));
        for (int i = 0; i < 27; i++) inv.setStack(i, white.copy());

        int[] slots = {11, 13, 15};
        for (int i = 0; i < 3 && i < results.size(); i++) {
            inv.setStack(slots[i], build3DStack(results.get(i), i + 1));
        }

        Text title = Text.empty()
                .append(Text.literal("G").setStyle(Style.EMPTY.withColor(0x4285F4).withBold(true)))
                .append(Text.literal("o").setStyle(Style.EMPTY.withColor(0xEA4335).withBold(true)))
                .append(Text.literal("o").setStyle(Style.EMPTY.withColor(0xFBBC05).withBold(true)))
                .append(Text.literal("g").setStyle(Style.EMPTY.withColor(0x4285F4).withBold(true)))
                .append(Text.literal("l").setStyle(Style.EMPTY.withColor(0x34A853).withBold(true)))
                .append(Text.literal("e").setStyle(Style.EMPTY.withColor(0xEA4335).withBold(true)))
                .append(Text.literal(" — " + query).formatted(Formatting.DARK_GRAY));

        player.openHandledScreen(new SimpleNamedScreenHandlerFactory((syncId, playerInv, p) ->
                new GenericContainerScreenHandler(ScreenHandlerType.GENERIC_9X3, syncId, playerInv, inv, 3) {
                    @Override
                    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity clicker) {
                        if (slotIndex == 11 || slotIndex == 13 || slotIndex == 15) {
                            ItemStack chosen = inv.getStack(slotIndex);
                            if (!chosen.isEmpty() && clicker instanceof ServerPlayerEntity sp) {
                                sp.getInventory().offerOrDrop(chosen.copy());
                                sp.closeHandledScreen();
                                sp.getServerWorld().playSound(null, sp.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.8f, 1.4f);
                                sp.sendMessage(Text.literal("[Google AI] Claimed ").formatted(Formatting.GREEN).append(chosen.getName()), false);
                            }
                        }
                    }

                    @Override
                    public ItemStack quickMove(PlayerEntity p2, int slot) { return ItemStack.EMPTY; }
                }, title));
    }

    private ItemStack build3DStack(GeneratedItem g, int rank) {
        Item item = Registries.ITEM.get(Identifier.ofVanilla(g.base_item != null ? g.base_item.toLowerCase() : "nether_star"));
        if (item == Items.AIR) item = Items.NETHER_STAR;
        int amt = Math.max(1, Math.min(64, g.amount <= 0 ? 1 : g.amount));
        ItemStack stack = new ItemStack(item, amt);

        // Apply Real 3D Model built right into the mod!
        String model3d = (g.model_3d != null && VALID_3D.contains(g.model_3d)) ? g.model_3d : "lucky_cube";
        stack.set(DataComponentTypes.ITEM_MODEL, Identifier.of(MOD_ID, model3d));

        TextColor col = TextColor.parse(g.color != null ? g.color : "#4285F4").result().orElse(TextColor.fromRgb(0x4285F4));
        stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal(g.name != null ? g.name : "AI 3D Item #" + rank)
                .setStyle(Style.EMPTY.withColor(col).withBold(true).withItalic(false)));

        List<Text> lore = new ArrayList<>();
        if (g.lore != null) {
            for (String line : g.lore) lore.add(Text.literal(line).formatted(Formatting.GRAY));
        }
        lore.add(Text.literal("⚡ 3D AI Power: " + (g.ability != null ? g.ability : "NONE")).formatted(Formatting.GOLD));
        lore.add(Text.literal("Google Gemini 3D Result #" + rank).formatted(Formatting.GREEN));
        stack.set(DataComponentTypes.LORE, new LoreComponent(lore));
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);

        NbtCompound nbt = new NbtCompound();
        nbt.putString("gsearch_ability", g.ability != null ? g.ability.toUpperCase() : "NONE");
        nbt.putDouble("gsearch_power", g.power > 0 ? g.power : 5.0);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        return stack;
    }
}
