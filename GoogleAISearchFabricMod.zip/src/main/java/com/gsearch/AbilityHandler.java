package com.gsearch;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AbilityHandler {

    private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();

    public static void register() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient || !(world instanceof ServerWorld sw)) return ActionResult.PASS;
            ItemStack stack = player.getStackInHand(hand);
            NbtComponent custom = stack.get(DataComponentTypes.CUSTOM_DATA);
            if (custom == null) return ActionResult.PASS;
            NbtCompound nbt = custom.copyNbt();
            if (!nbt.contains("gsearch_ability")) return ActionResult.PASS;

            String ab = nbt.getString("gsearch_ability");
            double pw = Math.max(1.0, Math.min(10.0, nbt.getDouble("gsearch_power")));
            if (ab.equals("ONE_PUNCH") || ab.equals("STEAL_INVENTORY")) return ActionResult.PASS;

            if (!checkCd(player)) return ActionResult.FAIL;
            executeRightClick(player, sw, ab, pw);
            return ActionResult.SUCCESS;
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient || !(world instanceof ServerWorld sw)) return ActionResult.PASS;
            ItemStack stack = player.getStackInHand(hand);
            NbtComponent custom = stack.get(DataComponentTypes.CUSTOM_DATA);
            if (custom == null) return ActionResult.PASS;
            NbtCompound nbt = custom.copyNbt();
            if (!nbt.contains("gsearch_ability")) return ActionResult.PASS;

            String ab = nbt.getString("gsearch_ability");
            if (ab.equals("ONE_PUNCH") && entity instanceof LivingEntity le) {
                le.damage(sw, sw.getDamageSources().playerAttack(player), 40.0f);
                Vec3d dir = player.getRotationVec(1.0f).multiply(2.8).add(0, 1.0, 0);
                le.setVelocity(dir);
                le.velocityModified = true;
            } else if (ab.equals("LIGHTNING_STRIKE")) {
                LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(sw, net.minecraft.entity.SpawnReason.TRIGGERED);
                if (bolt != null) { bolt.refreshPositionAfterTeleport(entity.getPos()); sw.spawnEntity(bolt); }
            } else if (ab.equals("STEAL_INVENTORY") && entity instanceof ServerPlayerEntity victim) {
                for (int i = 0; i < victim.getInventory().size(); i++) {
                    ItemStack st = victim.getInventory().getStack(i);
                    if (!st.isEmpty()) {
                        victim.dropItem(st.copy(), true, false);
                        victim.getInventory().setStack(i, ItemStack.EMPTY);
                    }
                }
                player.sendMessage(Text.literal("[Google AI] Stripped all items & armor from " + victim.getName().getString() + "!").formatted(Formatting.RED), false);
            }
            return ActionResult.PASS;
        });
    }

    private static boolean checkCd(PlayerEntity player) {
        long now = System.currentTimeMillis();
        long exp = COOLDOWNS.getOrDefault(player.getUuid(), 0L);
        if (now < exp) {
            player.sendMessage(Text.literal("Cooldown...").formatted(Formatting.RED), true);
            return false;
        }
        COOLDOWNS.put(player.getUuid(), now + 2000L);
        return true;
    }

    private static Vec3d targetPos(PlayerEntity p, double max) {
        HitResult hr = p.raycast(max, 0, false);
        return hr.getPos();
    }

    private static void executeRightClick(PlayerEntity p, ServerWorld sw, String ab, double pw) {
        Vec3d t = targetPos(p, 28);
        switch (ab) {
            case "NUKE_EXPLOSION" -> {
                sw.createExplosion(p, t.x, t.y, t.z, (float) Math.min(12.0, pw * 1.2), true, World.ExplosionSourceType.TNT);
                LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(sw, net.minecraft.entity.SpawnReason.TRIGGERED);
                if (bolt != null) { bolt.refreshPositionAfterTeleport(t); sw.spawnEntity(bolt); }
            }
            case "TNT_RAIN" -> {
                for (int i = 0; i < 5; i++) {
                    TntEntity tnt = new TntEntity(sw, t.x + (Math.random() - 0.5) * 4, t.y + 6 + i, t.z + (Math.random() - 0.5) * 4, p);
                    tnt.setFuse(35);
                    sw.spawnEntity(tnt);
                }
            }
            case "LIGHTNING_STRIKE" -> {
                for (int i = 0; i < 3; i++) {
                    LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(sw, net.minecraft.entity.SpawnReason.TRIGGERED);
                    if (bolt != null) { bolt.refreshPositionAfterTeleport(t); sw.spawnEntity(bolt); }
                }
            }
            case "FIREBALL_BARRAGE" -> {
                Vec3d look = p.getRotationVec(1.0f);
                FireballEntity fb = new FireballEntity(sw, p, look.multiply(1.5), (int) Math.min(5, Math.max(2, pw / 2)));
                fb.setPosition(p.getEyePos().add(look));
                sw.spawnEntity(fb);
            }
            case "FREEZE_NOVA", "TIME_STOP" -> {
                double r = ab.equals("TIME_STOP") ? 16.0 : 9.0;
                for (LivingEntity le : sw.getEntitiesByClass(LivingEntity.class, Box.of(p.getPos(), r * 2, r * 2, r * 2), e -> e != p)) {
                    le.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 140, 255));
                    le.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 100, 1));
                }
                sw.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.PLAYERS, 1.2f, 1.4f);
            }
            case "TELEPORT_BLINK" -> {
                p.requestTeleport(t.x, t.y + 1.0, t.z);
                sw.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 1.2f);
            }
            case "HEAL_AURA", "HEART_BOOST" -> {
                p.heal(20.0f);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 2));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 400, ab.equals("HEART_BOOST") ? 9 : 2));
                sw.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.9f, 1.5f);
            }
            case "BLACK_HOLE" -> {
                for (Entity e : sw.getOtherEntities(p, Box.of(t, 20, 20, 20))) {
                    e.requestTeleport(t.x, t.y + 0.5, t.z);
                }
                sw.createExplosion(p, t.x, t.y, t.z, 5.0f, true, World.ExplosionSourceType.TNT);
            }
            case "WIND_LAUNCH" -> {
                Vec3d v = p.getRotationVec(1.0f).multiply(1.4).add(0, 1.3, 0);
                p.setVelocity(v);
                p.velocityModified = true;
            }
            case "SUMMON_ALLY" -> {
                IronGolemEntity golem = EntityType.IRON_GOLEM.create(sw, net.minecraft.entity.SpawnReason.TRIGGERED);
                if (golem != null) {
                    golem.setPlayerCreated(true);
                    golem.refreshPositionAfterTeleport(p.getPos().add(p.getRotationVec(1.0f).multiply(2)));
                    sw.spawnEntity(golem);
                }
            }
        }
    }
}
