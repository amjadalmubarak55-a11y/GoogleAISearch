package com.gsearch;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public String openai_api_key = "PASTE_YOUR_OPENAI_API_KEY_HERE";
    public String model = "gpt-4o-mini";
    public int timeout_seconds = 20;

    public static ModConfig load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("google_ai_search.json");
        try {
            if (Files.exists(path)) {
                return GSON.fromJson(Files.readString(path), ModConfig.class);
            }
            ModConfig cfg = new ModConfig();
            Files.createDirectories(path.getParent());
            Files.writeString(path, GSON.toJson(cfg));
            return cfg;
        } catch (Exception e) {
            return new ModConfig();
        }
    }
}
