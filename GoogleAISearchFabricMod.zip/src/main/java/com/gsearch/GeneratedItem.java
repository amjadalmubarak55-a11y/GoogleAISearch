package com.gsearch;

import java.util.List;

public class GeneratedItem {
    public String name;
    public String color;
    public String base_item;
    public String model_3d;
    public int amount;
    public List<String> lore;
    public String ability;
    public double power;
}
