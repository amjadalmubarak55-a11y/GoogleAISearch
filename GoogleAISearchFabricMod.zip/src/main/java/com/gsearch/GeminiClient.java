package com.gsearch;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class GeminiClient {

    private static final Gson GSON = new Gson();
    private final HttpClient http;
    private final ModConfig config;

    private static final String SYSTEM_PROMPT =
        "You are a Minecraft 1.21.4 3D item designer. Given ANY player search query (in English, Arabic, or any language), " +
        "invent EXACTLY 3 unique, creative, overpowered Minecraft items that match what the player asked for. " +
        "Return ONLY a JSON object: {\"items\": [ ...3 items... ]} with NO markdown fences. Each item MUST have:\n" +
        "- name (string): Awesome name in the user's language\n" +
        "- color (string): Hex color like #4285F4\n" +
        "- base_item (string): Vanilla item id without namespace (e.g. netherite_sword, bow, mace, fishing_rod, trident, nether_star, tnt, blaze_rod, netherite_pickaxe)\n" +
        "- model_3d (string): MUST pick the best matching 3D model from: void_greatsword, nuke_launcher, thor_hammer, steal_rod, blackhole_staff, dragon_bow, royal_crown, lucky_cube\n" +
        "- amount (integer 1-64)\n" +
        "- lore (array of 2 short strings describing the item & power)\n" +
        "- ability (string): MUST be one of: NUKE_EXPLOSION, TNT_RAIN, LIGHTNING_STRIKE, FIREBALL_BARRAGE, FREEZE_NOVA, TIME_STOP, TELEPORT_BLINK, HEAL_AURA, HEART_BOOST, BLACK_HOLE, STEAL_INVENTORY, ONE_PUNCH, WIND_LAUNCH, SUMMON_ALLY\n" +
        "- power (number 1.0 to 10.0)";

    public GeminiClient(ModConfig config) {
        this.config = config;
        this.http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(config.timeout_seconds))
                .build();
    }

    public CompletableFuture<List<GeneratedItem>> searchTop3(String query) {
        List<String> models = new ArrayList<>();
        if (config.model != null && !config.model.isBlank()) models.add(config.model);
        for (String fb : List.of("gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite")) {
            if (!models.contains(fb)) models.add(fb);
        }
        return tryModel(query, models, 0);
    }

    private CompletableFuture<List<GeneratedItem>> tryModel(String query, List<String> models, int idx) {
        String model = models.get(idx);
        String url = "https://generativelanguage.googleapis.com/v1beta/models/"
                + model + ":generateContent?key=" + config.gemini_api_key;

        JsonObject payload = new JsonObject();
        JsonArray contents = new JsonArray();
        JsonObject msg = new JsonObject();
        JsonArray parts = new JsonArray();
        JsonObject textPart = new JsonObject();
        textPart.addProperty("text", SYSTEM_PROMPT + "\n\nPlayer searched for: " + query);
        parts.add(textPart);
        msg.add("parts", parts);
        contents.add(msg);
        payload.add("contents", contents);

        JsonObject genConfig = new JsonObject();
        genConfig.addProperty("responseMimeType", "application/json");
        payload.add("generationConfig", genConfig);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .timeout(Duration.ofSeconds(config.timeout_seconds))
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(payload)))
                .build();

        return http.sendAsync(req, HttpResponse.BodyHandlers.ofString())
                .thenCompose(resp -> {
                    int code = resp.statusCode();
                    if ((code == 503 || code == 429 || code == 404) && idx + 1 < models.size()) {
                        return tryModel(query, models, idx + 1);
                    }
                    if (code != 200) {
                        return CompletableFuture.failedFuture(new RuntimeException("Gemini HTTP " + code + ": " + resp.body()));
                    }
                    try {
                        JsonObject root = JsonParser.parseString(resp.body()).getAsJsonObject();
                        String raw = root.getAsJsonArray("candidates")
                                .get(0).getAsJsonObject()
                                .getAsJsonObject("content")
                                .getAsJsonArray("parts")
                                .get(0).getAsJsonObject()
                                .get("text").getAsString().trim();
                        if (raw.startsWith("```")) {
                            raw = raw.replaceAll("^```[a-zA-Z]*\s*", "").replaceAll("```$", "").trim();
                        }
                        JsonObject parsed = JsonParser.parseString(raw).getAsJsonObject();
                        Type t = new TypeToken<List<GeneratedItem>>() {}.getType();
                        List<GeneratedItem> list = GSON.fromJson(parsed.getAsJsonArray("items"), t);
                        if (list == null || list.size() < 3) {
                            return CompletableFuture.failedFuture(new RuntimeException("Gemini returned fewer than 3 items."));
                        }
                        return CompletableFuture.completedFuture(list.subList(0, 3));
                    } catch (Exception e) {
                        return CompletableFuture.failedFuture(e);
                    }
                });
    }
}
