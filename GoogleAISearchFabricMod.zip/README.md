# Google AI Search 3D — Fabric Mod (Minecraft 1.21.4) + OpenAI API

Real Fabric Mod powered by **OpenAI (`gpt-4o-mini` / `gpt-4o`)** featuring **8 built-in 3D Blockbench-style item models**, `/search <anything>` (English & Arabic), Google Top-3 GUI, and **14 live abilities** (`NUKE_EXPLOSION`, `STEAL_INVENTORY`, `BLACK_HOLE`, `TIME_STOP`, `LIGHTNING_STRIKE`, etc.).

## 1-Click Build on GitHub
1. Upload `GoogleAISearchFabricMod.zip` to a GitHub repo and copy `.github/workflows/build.yml` into Actions.
2. Download `GoogleAISearch-Fabric-Mod` from Actions Artifacts (`google-ai-search-1.0.0.jar`).

## Install & Run
1. Install **Fabric Loader 1.21.4** + **Fabric API**.
2. Put `google-ai-search-1.0.0.jar` in `.minecraft/mods/` (and server `mods/`).
3. Launch once to generate `config/google_ai_search.json`, paste your **OpenAI API Key** (`sk-...`) from https://platform.openai.com/api-keys, and restart!
4. Run `/search NUKE BAZOOKA` or `/search صنارة السرقة` or `/search سيف يطلق برق`!
