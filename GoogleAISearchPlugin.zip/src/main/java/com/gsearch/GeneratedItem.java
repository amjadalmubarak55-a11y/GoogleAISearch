package com.gsearch;

import java.util.List;
import java.util.Map;

public class GeneratedItem {
    public String name;
    public String color;
    public String material;
    public int amount;
    public List<String> lore;
    public Map<String, Integer> enchantments;
    public String ability;
    public double power;
    public int cooldown;
    public String effect;
}
