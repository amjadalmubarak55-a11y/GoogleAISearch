package com.gsearch;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SearchGui implements Listener {

    private final GoogleAISearchPlugin plugin;

    public static class GoogleHolder implements InventoryHolder {
        private final String query;
        public GoogleHolder(String query) { this.query = query; }
        public String getQuery() { return query; }
        @Override public Inventory getInventory() { return null; }
    }

    public SearchGui(GoogleAISearchPlugin plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, String query, List<GeneratedItem> results) {
        Component title = Component.empty()
                .append(Component.text("G", TextColor.color(0x4285F4), TextDecoration.BOLD))
                .append(Component.text("o", TextColor.color(0xEA4335), TextDecoration.BOLD))
                .append(Component.text("o", TextColor.color(0xFBBC05), TextDecoration.BOLD))
                .append(Component.text("g", TextColor.color(0x4285F4), TextDecoration.BOLD))
                .append(Component.text("l", TextColor.color(0x34A853), TextDecoration.BOLD))
                .append(Component.text("e", TextColor.color(0xEA4335), TextDecoration.BOLD))
                .append(Component.text(" — " + query, NamedTextColor.DARK_GRAY));

        Inventory inv = Bukkit.createInventory(new GoogleHolder(query), 27, title);

        // Clean white Google backdrop + 4-color top bar
        ItemStack whitePane = makePane(Material.WHITE_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, whitePane);

        inv.setItem(0, makePane(Material.BLUE_STAINED_GLASS_PANE, " "));
        inv.setItem(1, makePane(Material.BLUE_STAINED_GLASS_PANE, " "));
        inv.setItem(2, makePane(Material.RED_STAINED_GLASS_PANE, " "));
        inv.setItem(3, makePane(Material.RED_STAINED_GLASS_PANE, " "));
        inv.setItem(4, makePane(Material.YELLOW_STAINED_GLASS_PANE, " "));
        inv.setItem(5, makePane(Material.BLUE_STAINED_GLASS_PANE, " "));
        inv.setItem(6, makePane(Material.GREEN_STAINED_GLASS_PANE, " "));
        inv.setItem(7, makePane(Material.GREEN_STAINED_GLASS_PANE, " "));
        inv.setItem(8, makePane(Material.RED_STAINED_GLASS_PANE, " "));

        // Place strictly Top 3 AI-crafted items in slots 11, 13, 15
        int[] slots = {11, 13, 15};
        for (int i = 0; i < 3 && i < results.size(); i++) {
            inv.setItem(slots[i], buildItemStack(results.get(i), i + 1));
        }

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.8f, 1.4f);
    }

    private ItemStack makePane(Material mat, String name) {
        ItemStack pane = new ItemStack(mat);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.text(name).decoration(TextDecoration.ITALIC, false));
            pane.setItemMeta(meta);
        }
        return pane;
    }

    private ItemStack buildItemStack(GeneratedItem g, int rank) {
        Material mat = Material.matchMaterial(g.material == null ? "NETHER_STAR" : g.material.toUpperCase(Locale.ROOT));
        if (mat == null || !mat.isItem() || mat == Material.AIR) {
            mat = Material.NETHER_STAR;
        }
        int amt = Math.max(1, Math.min(64, g.amount <= 0 ? 1 : g.amount));
        ItemStack stack = new ItemStack(mat, amt);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            TextColor color = TextColor.fromHexString(g.color != null ? g.color : "#4285F4");
            if (color == null) color = TextColor.color(0x4285F4);

            meta.displayName(Component.text(g.name != null ? g.name : "Google AI Item #" + rank, color)
                    .decorate(TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));

            List<Component> lore = new ArrayList<>();
            if (g.lore != null) {
                for (String line : g.lore) {
                    lore.add(Component.text(line, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
                }
            }
            if (g.ability != null && !g.ability.equalsIgnoreCase("NONE")) {
                lore.add(Component.text("⚡ Ability: " + g.ability + " (Right-Click / Hit)", TextColor.color(0xFBBC05))
                        .decoration(TextDecoration.ITALIC, false));
            }
            lore.add(Component.text("Google AI Result #" + rank, TextColor.color(0x34A853))
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(lore);
            meta.setUnbreakable(true);

            // Store dynamic ability parameters in PersistentDataContainer
            var pdc = meta.getPersistentDataContainer();
            pdc.set(plugin.KEY_ABILITY, PersistentDataType.STRING, g.ability != null ? g.ability.toUpperCase(Locale.ROOT) : "NONE");
            pdc.set(plugin.KEY_POWER, PersistentDataType.DOUBLE, g.power > 0 ? Math.min(10.0, g.power) : 3.0);
            pdc.set(plugin.KEY_COOLDOWN, PersistentDataType.INTEGER, Math.max(1, Math.min(30, g.cooldown <= 0 ? 3 : g.cooldown)));
            pdc.set(plugin.KEY_EFFECT, PersistentDataType.STRING, g.effect != null ? g.effect.toUpperCase(Locale.ROOT) : "");

            stack.setItemMeta(meta);
        }

        // Apply AI-chosen enchantments (unsafe levels supported!)
        if (g.enchantments != null && plugin.getConfig().getBoolean("settings.allow-op-enchantments", true)) {
            for (Map.Entry<String, Integer> entry : g.enchantments.entrySet()) {
                NamespacedKey key = NamespacedKey.minecraft(entry.getKey().toLowerCase(Locale.ROOT).replace("minecraft:", ""));
                Enchantment ench = Registry.ENCHANTMENT.get(key);
                if (ench != null) {
                    int lvl = Math.max(1, Math.min(10, entry.getValue()));
                    stack.addUnsafeEnchantment(ench, lvl);
                }
            }
        }
        return stack;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof GoogleHolder)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;

        int slot = event.getRawSlot();
        if (slot != 11 && slot != 13 && slot != 15) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        player.getInventory().addItem(clicked.clone());
        player.closeInventory();
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.35f);
        player.spawnParticle(Particle.HAPPY_VILLAGER, player.getLocation().add(0, 1.2, 0), 15, 0.4, 0.4, 0.4);
        player.sendMessage(Component.text("[Google AI] ", TextColor.color(0x4285F4), TextDecoration.BOLD)
                .append(Component.text("Claimed ", NamedTextColor.WHITE))
                .append(clicked.displayName()));
    }
}
