package com.gsearch;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class GeminiClient {

    private static final Gson GSON = new Gson();
    private final HttpClient http;
    private final String apiKey;
    private final String model;
    private final int timeoutSeconds;

    private static final String SYSTEM_PROMPT =
        "You are an expert Minecraft 1.21+ item designer. " +
        "Given ANY player search query (in English, Arabic, or any language), invent EXACTLY 3 distinct, creative, fun custom Minecraft items matching what the player asked for. " +
        "Return ONLY a valid JSON array of 3 objects with NO markdown fences and NO extra text. " +
        "Each object MUST have these exact keys:\n" +
        "- name (string): Creative item name matching the query language/theme\n" +
        "- color (string): Hex color like #4285F4 or #EF4444\n" +
        "- material (string): Valid uppercase Bukkit Material name (e.g. NETHERITE_SWORD, TNT, MACE, BOW, TRIDENT, BLAZE_ROD, NETHER_STAR, GOLDEN_APPLE, ELYTRA, TOTEM_OF_UNDYING, FIRE_CHARGE, DIAMOND_PICKAXE, ENDER_PEARL, HEART_OF_THE_SEA)\n" +
        "- amount (integer 1-64): Stack size (1 for tools/weapons/armor/relics, up to 64 for consumables/blocks)\n" +
        "- lore (array of 2-3 short strings): Cool flavor text + ability description\n" +
        "- enchantments (object mapping lowercase minecraft enchantment id to integer level 1-10, e.g. {\"sharpness\": 8, \"unbreaking\": 10})\n" +
        "- ability (string): MUST be one of: NUKE_EXPLOSION, LIGHTNING_STRIKE, FIREBALL_BARRAGE, TELEPORT_BLINK, HEAL_AURA, FREEZE_NOVA, WIND_LAUNCH, LIFESTEAL_WITHER, SUMMON_ALLY, METEOR_SHOWER, SPEED_DASH, POTION_BUFF, NONE\n" +
        "- power (number 1.0 to 10.0): Ability strength (e.g. explosion radius, lightning count, teleport distance * 3)\n" +
        "- cooldown (integer 1 to 15): Cooldown in seconds\n" +
        "- effect (string): Optional uppercase PotionEffectType for POTION_BUFF (e.g. SPEED, STRENGTH, INVISIBILITY, JUMP_BOOST, NIGHT_VISION, FIRE_RESISTANCE, REGENERATION, LEVITATION) or empty string.";

    public GeminiClient(String apiKey, String model, int timeoutSeconds) {
        this.apiKey = apiKey;
        this.model = model;
        this.timeoutSeconds = timeoutSeconds;
        this.http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(timeoutSeconds))
                .build();
    }

    public CompletableFuture<List<GeneratedItem>> searchTop3(String query) {
        String url = "https://generativelanguage.googleapis.com/v1beta/models/"
                + model + ":generateContent?key=" + apiKey;

        JsonObject payload = new JsonObject();
        JsonArray contents = new JsonArray();
        JsonObject userMsg = new JsonObject();
        JsonArray parts = new JsonArray();
        JsonObject textPart = new JsonObject();
        textPart.addProperty("text", SYSTEM_PROMPT + "\n\nPlayer search query: \"" + query + "\"");
        parts.add(textPart);
        userMsg.add("parts", parts);
        contents.add(userMsg);
        payload.add("contents", contents);

        JsonObject genConfig = new JsonObject();
        genConfig.addProperty("responseMimeType", "application/json");
        genConfig.addProperty("temperature", 0.85);
        payload.add("generationConfig", genConfig);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .timeout(Duration.ofSeconds(timeoutSeconds))
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(payload)))
                .build();

        return http.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    if (response.statusCode() != 200) {
                        throw new RuntimeException("Gemini API HTTP " + response.statusCode() + ": " + response.body());
                    }
                    JsonObject root = JsonParser.parseString(response.body()).getAsJsonObject();
                    String rawJson = root.getAsJsonArray("candidates")
                            .get(0).getAsJsonObject()
                            .getAsJsonObject("content")
                            .getAsJsonArray("parts")
                            .get(0).getAsJsonObject()
                            .get("text").getAsString()
                            .trim();

                    if (rawJson.startsWith("```")) {
                        rawJson = rawJson.replaceAll("^```[a-zA-Z]*\s*", "").replaceAll("```$", "").trim();
                    }

                    Type listType = new TypeToken<List<GeneratedItem>>() {}.getType();
                    List<GeneratedItem> items = GSON.fromJson(rawJson, listType);
                    if (items == null || items.size() < 3) {
                        throw new RuntimeException("Gemini returned fewer than 3 items.");
                    }
                    return items.subList(0, 3);
                });
    }
}
