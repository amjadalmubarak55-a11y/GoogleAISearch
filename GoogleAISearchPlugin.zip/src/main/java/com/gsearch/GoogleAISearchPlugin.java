package com.gsearch;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GoogleAISearchPlugin extends JavaPlugin implements CommandExecutor {

    public NamespacedKey KEY_ABILITY;
    public NamespacedKey KEY_POWER;
    public NamespacedKey KEY_COOLDOWN;
    public NamespacedKey KEY_EFFECT;

    private GeminiClient gemini;
    private SearchGui gui;
    private final Map<UUID, Long> searchCooldowns = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        KEY_ABILITY = new NamespacedKey(this, "ability");
        KEY_POWER = new NamespacedKey(this, "power");
        KEY_COOLDOWN = new NamespacedKey(this, "cooldown");
        KEY_EFFECT = new NamespacedKey(this, "effect");

        String apiKey = getConfig().getString("gemini.api-key", "");
        String model = getConfig().getString("gemini.model", "gemini-2.5-flash");
        int timeout = getConfig().getInt("gemini.timeout-seconds", 15);

        this.gemini = new GeminiClient(apiKey, model, timeout);
        this.gui = new SearchGui(this);

        getServer().getPluginManager().registerEvents(gui, this);
        getServer().getPluginManager().registerEvents(new AbilityListener(this), this);

        var cmd = getCommand("search");
        if (cmd != null) cmd.setExecutor(this);

        getLogger().info("GoogleAISearch enabled! Use /search <anything>");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use /search.");
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(Component.text("[Google AI] ", TextColor.color(0x4285F4), TextDecoration.BOLD)
                    .append(Component.text("Usage: /search <anything you want> (e.g. /search NUKE or /search سيف يطلق برق)", NamedTextColor.GRAY)));
            return true;
        }

        String apiKey = getConfig().getString("gemini.api-key", "");
        if (apiKey.isEmpty() || apiKey.equals("PASTE_YOUR_GEMINI_API_KEY_HERE")) {
            player.sendMessage(Component.text("[Google AI] Please set your Gemini API key in plugins/GoogleAISearch/config.yml!", NamedTextColor.RED));
            return true;
        }

        long now = System.currentTimeMillis();
        int cdSec = getConfig().getInt("settings.search-cooldown-seconds", 3);
        long exp = searchCooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < exp) {
            player.sendMessage(Component.text("[Google AI] Wait " + ((exp - now) / 1000 + 1) + "s before searching again.", NamedTextColor.YELLOW));
            return true;
        }
        searchCooldowns.put(player.getUniqueId(), now + cdSec * 1000L);

        String query = String.join(" ", args);
        player.sendMessage(Component.text("[Google AI] ", TextColor.color(0x4285F4), TextDecoration.BOLD)
                .append(Component.text("Crafting Top 3 custom results for "" + query + ""...", NamedTextColor.GRAY)));

        gemini.searchTop3(query).whenComplete((items, err) -> Bukkit.getScheduler().runTask(this, () -> {
            if (err != null) {
                getLogger().warning("Gemini search failed: " + err.getMessage());
                player.sendMessage(Component.text("[Google AI] Search failed — check server console & API key.", NamedTextColor.RED));
                return;
            }
            if (player.isOnline()) {
                gui.open(player, query, items);
            }
        }));
        return true;
    }
}
