package com.gsearch;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AbilityListener implements Listener {

    private final GoogleAISearchPlugin plugin;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public AbilityListener(GoogleAISearchPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;

        var pdc = item.getItemMeta().getPersistentDataContainer();
        String ability = pdc.get(plugin.KEY_ABILITY, PersistentDataType.STRING);
        if (ability == null || ability.equals("NONE") || ability.equals("LIFESTEAL_WITHER")) return;

        int cdSec = pdc.getOrDefault(plugin.KEY_COOLDOWN, PersistentDataType.INTEGER, 3);
        if (!checkCooldown(player, cdSec)) return;

        double power = pdc.getOrDefault(plugin.KEY_POWER, PersistentDataType.DOUBLE, 3.0);
        String effectName = pdc.getOrDefault(plugin.KEY_EFFECT, PersistentDataType.STRING, "");
        Location target = getTargetLocation(player, 24);
        World w = player.getWorld();

        switch (ability) {
            case "NUKE_EXPLOSION" -> {
                float radius = (float) Math.min(12.0, Math.max(3.0, power * 1.2));
                w.createExplosion(target, radius, true, true, player);
                w.spawnParticle(Particle.EXPLOSION_EMITTER, target, 4, 1.5, 1.5, 1.5);
                w.playSound(target, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.7f);
            }
            case "LIGHTNING_STRIKE" -> {
                int strikes = Math.max(1, Math.min(5, (int) Math.round(power / 2.0)));
                for (int i = 0; i < strikes; i++) {
                    Location loc = target.clone().add((Math.random() - 0.5) * 3, 0, (Math.random() - 0.5) * 3);
                    w.strikeLightning(loc);
                }
            }
            case "FIREBALL_BARRAGE" -> {
                Fireball fb = player.launchProjectile(Fireball.class);
                fb.setYield((float) Math.min(6.0, Math.max(2.0, power * 0.7)));
                fb.setIsIncendiary(true);
                w.playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 1.0f);
            }
            case "TELEPORT_BLINK" -> {
                Location dest = getTargetLocation(player, Math.min(30, (int) (power * 3)));
                dest.setYaw(player.getLocation().getYaw());
                dest.setPitch(player.getLocation().getPitch());
                player.teleport(dest.add(0, 1, 0));
                w.spawnParticle(Particle.PORTAL, dest, 30, 0.5, 0.8, 0.5);
                w.playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.2f);
            }
            case "HEAL_AURA" -> {
                player.setHealth(Math.min(player.getMaxHealth(), player.getHealth() + power * 2.0));
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 160, 2));
                player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 1));
                w.spawnParticle(Particle.HEART, player.getLocation().add(0, 1.5, 0), 12, 0.5, 0.4, 0.5);
                w.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
            }
            case "FREEZE_NOVA" -> {
                double r = Math.max(4.0, power * 1.2);
                for (Entity e : player.getNearbyEntities(r, r, r)) {
                    if (e instanceof LivingEntity le && e != player) {
                        le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 140, 4));
                        le.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 140, 3));
                        le.setFreezeTicks(200);
                    }
                }
                w.spawnParticle(Particle.SNOWFLAKE, player.getLocation().add(0, 1, 0), 60, r / 2, 1, r / 2);
                w.playSound(player.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.2f, 1.5f);
            }
            case "WIND_LAUNCH" -> {
                Vector vel = player.getLocation().getDirection().multiply(1.4).setY(Math.min(2.2, 0.8 + power * 0.15));
                player.setVelocity(vel);
                w.spawnParticle(Particle.GUST_EMITTER_LARGE, player.getLocation(), 2);
                w.playSound(player.getLocation(), Sound.ENTITY_WIND_CHARGE_WIND_BURST, 1.0f, 1.0f);
            }
            case "SUMMON_ALLY" -> {
                IronGolem golem = (IronGolem) w.spawnEntity(player.getLocation().add(player.getLocation().getDirection().multiply(2)), EntityType.IRON_GOLEM);
                golem.setPlayerCreated(true);
                w.playSound(golem.getLocation(), Sound.ENTITY_IRON_GOLEM_REPAIR, 1.0f, 1.0f);
            }
            case "METEOR_SHOWER" -> {
                for (int i = 0; i < 4; i++) {
                    Location sky = target.clone().add((Math.random() - 0.5) * 6, 14 + i * 2, (Math.random() - 0.5) * 6);
                    Fireball meteor = w.spawn(sky, Fireball.class);
                    meteor.setShooter(player);
                    meteor.setDirection(new Vector(0, -1.5, 0));
                    meteor.setYield(3.0f);
                }
            }
            case "SPEED_DASH" -> {
                player.setVelocity(player.getLocation().getDirection().multiply(Math.min(3.0, 1.2 + power * 0.2)));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 160, 3));
                w.spawnParticle(Particle.CLOUD, player.getLocation(), 25, 0.4, 0.2, 0.4);
                w.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.9f, 1.3f);
            }
            case "POTION_BUFF" -> {
                PotionEffectType type = Registry.EFFECT.get(NamespacedKey.minecraft(effectName.toLowerCase()));
                if (type == null) type = PotionEffectType.STRENGTH;
                player.addPotionEffect(new PotionEffect(type, 300, Math.max(0, Math.min(4, (int) power / 2))));
                w.playSound(player.getLocation(), Sound.ENTITY_WITCH_DRINK, 0.9f, 1.2f);
            }
        }
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;
        ItemStack item = player.getInventory().getItemInMainHand();
        if (!item.hasItemMeta()) return;

        String ability = item.getItemMeta().getPersistentDataContainer().get(plugin.KEY_ABILITY, PersistentDataType.STRING);
        if ("LIFESTEAL_WITHER".equals(ability)) {
            target.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1));
            double heal = event.getFinalDamage() * 0.5;
            player.setHealth(Math.min(player.getMaxHealth(), player.getHealth() + heal));
            player.getWorld().spawnParticle(Particle.HEART, player.getLocation().add(0, 1.6, 0), 4, 0.3, 0.2, 0.3);
        } else if ("LIGHTNING_STRIKE".equals(ability)) {
            target.getWorld().strikeLightning(target.getLocation());
        }
    }

    private boolean checkCooldown(Player player, int seconds) {
        long now = System.currentTimeMillis();
        long expire = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < expire) {
            long left = (expire - now) / 1000 + 1;
            player.sendActionBar(Component.text("Cooldown: " + left + "s", NamedTextColor.RED));
            return false;
        }
        cooldowns.put(player.getUniqueId(), now + seconds * 1000L);
        return true;
    }

    private Location getTargetLocation(Player player, int maxDist) {
        var block = player.getTargetBlockExact(maxDist);
        if (block != null) return block.getLocation().add(0.5, 1.0, 0.5);
        return player.getEyeLocation().add(player.getLocation().getDirection().multiply(Math.min(12, maxDist)));
    }
}
