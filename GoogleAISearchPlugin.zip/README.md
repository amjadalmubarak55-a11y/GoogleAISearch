# GoogleAISearch — Paper Plugin (1.21+ / 26.x) powered by Gemini AI

Type **`/search <anything>`** (in English or Arabic — e.g. `/search NUKE`, `/search سيف يطلق برق`, `/search flying meteor staff`) and **Gemini AI** dynamically invents and crafts **3 real custom Minecraft items** with custom names, lore, OP enchantments, and **12 real server-side abilities** (nuke explosions, lightning strikes, fireballs, meteor showers, teleport blink, freeze nova, wind launch, lifesteal+wither, iron golem summons, heal aura, speed dash, custom buffs) inside a Google-themed GUI!

## How to Build the `.jar` File

### Option 1: Build with Maven on Your PC (Java 21+)
```bash
mvn clean package
```
Your compiled plugin will be at: `target/GoogleAISearch-1.0.0.jar`

### Option 2: 1-Click Build on GitHub (No Java/Maven needed!)
1. Upload this folder to a new GitHub repository.
2. Open the **Actions** tab → click **Build GoogleAISearch Plugin JAR** → download `GoogleAISearch-JAR`.

## Installation & Setup
1. Drop `GoogleAISearch-1.0.0.jar` into your Paper/Purpur server's `plugins/` folder and start the server.
2. Get a free Gemini API key from [Google AI Studio](https://aistudio.google.com/apikey).
3. Open `plugins/GoogleAISearch/config.yml`, paste your API key into `gemini.api-key`, and restart the server.
4. Run `/search NUKE` or `/search <anything>` in-game!

> **Note for Aternos:** Aternos restricts custom `.jar` uploads to plugins published on Modrinth/SpigotMC/Hangar. To run a custom-built `.jar`, use a Paper/Purpur host that allows custom plugin uploads (e.g. local Paper server, VPS, Falix, PebbleHost, etc.).
